jQuery(document).ready(function(){
	
	/*
	 *
	 * SW_Options_date function
	 * Adds datepicker js
	 *
	 */
	jQuery('.sw-opts-datepicker').datepicker( {
		dateFormat: "mm/dd/yy"
	} );
	
});